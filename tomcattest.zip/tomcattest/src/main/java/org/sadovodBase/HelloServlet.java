package org.sadovodBase;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/hello")
public class HelloServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {

        resp.setContentType("text/html;charset=UTF-8");
        resp.getWriter().println(
                "<html>" +
                "<body>" +

                        "<h1>Artem Sokolov</h1>" +
                        "<p>Ненавижу жизнь, учусь в Ithub на 3 курсе. Родился 29 октября 2006 года. По жизни двигаюсь ровно</p>" +


                        "<h2>Хобии</h2>" +

                        "<ul>" +
                        "<li>Литрбол</li>" +
                        "<li>dota2</li>" +
                        "<li>cs2</li>" +
                        "<li>street racing</li>" +
                        "</ul>" +

                        "<h3>Обратная связь</h3>" +

                        "<form>" +
                        "<label>Имя:</label><br>" +
                        "<input type='text' name='name'><br><br>" +

                        "<label>Email:</label><br>" +
                        "<input type='email' name='email'><br><br>" +

                        "<label>Сообщение:</label><br>" +
                        "<textarea name='message'></textarea><br><br>" +

                        "<button type='button'>Отправить</button>" +
                        "</form>" +

                        "</body>" +
                        "</html>"
        );
    }
}